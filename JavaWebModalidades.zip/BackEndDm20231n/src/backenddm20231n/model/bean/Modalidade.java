/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backenddm20231n.model.bean;

/**
 *
 * @author User
 */
public class Modalidade {
    
    private int id;
    private String modalidade;
    private String assinatura;
    private String campo;

    public Modalidade(int id) {
        this.id = id;
    }

    public Modalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public Modalidade(String modalidade, String assinatura, String campo) {
        this.modalidade = modalidade;
        this.assinatura = assinatura;
        this.campo = campo;
    }

    public Modalidade(int id, String modalidade, String assinatura, String campo) {
        this.id = id;
        this.modalidade = modalidade;
        this.assinatura = assinatura;
        this.campo = campo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public String getAssinatura() {
        return assinatura;
    }

    public void setAssinatura(String assinatura) {
        this.assinatura = assinatura;
    }

    public String getCampo() {
        return campo;
    }

    public void setCampo(String campo) {
        this.campo = campo;
    }

    @Override
    public String toString() {
        return "Modalidade{" + "id=" + id + ", modalidade=" + modalidade + ", assinatura=" + assinatura + ", campo=" + campo + '}';
    }

   
    
    
}
