/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backenddm20231n.controller;

import backenddm20231n.model.bean.Modalidade;
import backenddm20231n.model.bean.Pessoa;
import backenddm20231n.model.bean.PessoasModalidade;
import backenddm20231n.model.dao.DaoPessoasModalidades;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class ControllerPessoasModalidades {
    
    DaoPessoasModalidades daoPesLog;
    ControllerPessoa contP;
    ControllerModalidades contL;

    
    public PessoasModalidade inserir(PessoasModalidade peslogEnt) throws SQLException, ClassNotFoundException {
        daoPesLog = new DaoPessoasModalidades();
        return daoPesLog.inserir(peslogEnt);
    }

    public PessoasModalidade alterar(PessoasModalidade peslogEnt) throws SQLException, ClassNotFoundException {
        daoPesLog = new DaoPessoasModalidades();
        return daoPesLog.alterar(peslogEnt);
    }

    public PessoasModalidade buscar(PessoasModalidade peslogEnt) throws SQLException, ClassNotFoundException {
        daoPesLog = new DaoPessoasModalidades();
        PessoasModalidade pl = daoPesLog.buscar(peslogEnt);
        Pessoa p = new Pessoa(pl.getIdPessoa());
        Modalidade l = new Modalidade(pl.getIdModalidade());
        contP = new ControllerPessoa();
        contL = new ControllerModalidades();
        pl.setP(contP.buscar(p));
        pl.setM(contL.buscar(l));
        return pl;
    }

    public PessoasModalidade excluir(PessoasModalidade peslogEnt) throws SQLException, ClassNotFoundException {
        daoPesLog = new DaoPessoasModalidades();
        return daoPesLog.excluir(peslogEnt);
    }

     public List<PessoasModalidade> listar(PessoasModalidade peslogEnt) throws SQLException, ClassNotFoundException {
        daoPesLog = new DaoPessoasModalidades();
        List<PessoasModalidade> listapeslog = daoPesLog.listar(peslogEnt);
        List<PessoasModalidade> listapeslogAux = new ArrayList<>();

        for (PessoasModalidade plSaida : listapeslog) {
            listapeslogAux.add(buscar(plSaida));
        }

        return listapeslogAux;
     }
   
}
