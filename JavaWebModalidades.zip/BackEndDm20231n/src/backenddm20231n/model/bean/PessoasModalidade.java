/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backenddm20231n.model.bean;

/**
 *
 * @author User
 */
public class PessoasModalidade {
    
    private int id;
    private int idPessoa;
    private int idModalidade;
    private String obs;
    private Pessoa p;
    private Modalidade m;

    public PessoasModalidade(int id) {
        this.id = id;
    }

    public PessoasModalidade(String obs) {
        this.obs = obs;
    }

    public PessoasModalidade(int idPessoa, int idModalidade, String obs) {
        this.idPessoa = idPessoa;
        this.idModalidade = idModalidade;
        this.obs = obs;
    }

    public PessoasModalidade(int id, int idPessoa, int idModalidade, String obs) {
        this.id = id;
        this.idPessoa = idPessoa;
        this.idModalidade = idModalidade;
        this.obs = obs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    public int getIdModalidade() {
        return idModalidade;
    }

    public void setIdModalidade(int idModalidade) {
        this.idModalidade = idModalidade;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Pessoa getP() {
        return p;
    }

    public void setP(Pessoa p) {
        this.p = p;
    }

    public Modalidade getM() {
        return m;
    }

    public void setM(Modalidade m) {
        this.m = m;
    }

    @Override
    public String toString() {
        return "PessoasModalidade{" + "id=" + id + ", idPessoa=" + idPessoa + ", idModalidade=" + idModalidade + ", obs=" + obs + ", p=" + p + ", m=" + m + '}';
    }  
    
    
}
