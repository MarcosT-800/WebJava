/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backenddm20231n.controller;

import backenddm20231n.model.bean.Modalidade;
import backenddm20231n.model.dao.DaoModalidade;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class ControllerModalidades {
    
    DaoModalidade daoLog;

    public Modalidade inserir(Modalidade logEnt) throws SQLException, ClassNotFoundException {
        daoLog = new DaoModalidade();
        return daoLog.inserir(logEnt);
    }

    public Modalidade alterar(Modalidade logEnt) throws SQLException, ClassNotFoundException {
        daoLog = new DaoModalidade();
        return daoLog.alterar(logEnt);
    }

    public Modalidade buscar(Modalidade logEnt) throws SQLException, ClassNotFoundException {
        daoLog = new DaoModalidade();
        return daoLog.buscar(logEnt);
    }

    public Modalidade excluir(Modalidade logEnt) throws SQLException, ClassNotFoundException {
        daoLog = new DaoModalidade();
        return daoLog.excluir(logEnt);
    }

     public List<Modalidade> listar(Modalidade logEnt) throws SQLException, ClassNotFoundException {
        daoLog = new DaoModalidade();
        List<Modalidade> listaLog = daoLog.listar(logEnt);
        return listaLog;
     }
   
}
