/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backenddm20231n.model.dao;

import backenddm20231n.model.bean.Modalidade;
import backenddm20231n.util.ConexaoDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class DaoModalidade {

private final Connection c;
    
    public DaoModalidade() throws SQLException, ClassNotFoundException{
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public Modalidade excluir(Modalidade logEnt) throws SQLException{
        String sql = "delete from Modalidade WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,logEnt.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return logEnt;
    }
    
    public Modalidade buscar(Modalidade logEnt) throws SQLException{
        String sql = "select * from modalidade WHERE id = ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,logEnt.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            Modalidade logSaida = null;
            while (rs.next()) {      
            // criando o objeto Usuario
                logSaida = new Modalidade(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4));
            // adiciona o usu à lista de usus
            }
            stmt.close();
        return logSaida;
   }

    public Modalidade inserir(Modalidade logEnt) throws SQLException{
        String sql = "insert into modalidade" + " (modalidade, assinatura, campo)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setString(1,logEnt.getModalidade());
        stmt.setString(2,logEnt.getAssinatura());
        stmt.setString(3,logEnt.getCampo());

        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            logEnt.setId(id);
        }
        stmt.close();
        return logEnt;
    }

    public Modalidade alterar(Modalidade logEnt) throws SQLException{
        String sql = "UPDATE modalidade SET modalidade = ?, assinatura = ?, campo = ? WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,logEnt.getModalidade());
        stmt.setString(2,logEnt.getAssinatura());
        stmt.setString(3,logEnt.getCampo());
        stmt.setInt(4,logEnt.getId());

        // executa
        stmt.execute();
        stmt.close();
        return logEnt;
    }

   public List<Modalidade> listar(Modalidade logEnt) throws SQLException{
        // usus: array armazena a lista de registros

        List<Modalidade> logs = new ArrayList<>();
        
        String sql = "select * from modalidade where modalidade like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + logEnt.getModalidade() + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Modalidade log = new Modalidade(
                rs.getInt(1),
                rs.getString(2),
                rs.getString(3),
                rs.getString(4));
            // adiciona o usu à lista de usus
            logs.add(log);
        }
        
        rs.close();
        stmt.close();
        return logs;
   
   }

    
}
