/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backenddm20231n.model.dao;

import backenddm20231n.model.bean.PessoasModalidade;
import backenddm20231n.util.ConexaoDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class DaoPessoasModalidades {

private final Connection c;
    
    public DaoPessoasModalidades() throws SQLException, ClassNotFoundException{
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public PessoasModalidade excluir(PessoasModalidade peslogEnt) throws SQLException{
        String sql = "delete from pessoas_modalidades WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,peslogEnt.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return peslogEnt;
    }
    
    public PessoasModalidade buscar(PessoasModalidade peslogEnt) throws SQLException{
        String sql = "select * from pessoas_modalidades WHERE id = ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,peslogEnt.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            PessoasModalidade peslogSaida = null;
            while (rs.next()) {      
            // criando o objeto Usuario
                peslogSaida = new PessoasModalidade(
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getInt(3),
                    rs.getString(4));
            // adiciona o usu à lista de usus
            }
            stmt.close();
        return peslogSaida;
   }

    public PessoasModalidade inserir(PessoasModalidade peslogEnt) throws SQLException{
        String sql = "insert into pessoas_modalidades" + " (idPessoa, idModalidade, obs)" + " values (?,?,?)";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setInt(1,peslogEnt.getIdPessoa());
        stmt.setInt(2,peslogEnt.getIdModalidade());
        stmt.setString(3,peslogEnt.getObs());

        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            peslogEnt.setId(id);
        }
        stmt.close();
        return peslogEnt;
    }

    public PessoasModalidade alterar(PessoasModalidade peslogEnt) throws SQLException{
        String sql = "UPDATE pessoas_modalidades SET idPessoa = ?, idModalidade = ?, obs = ? WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,peslogEnt.getIdPessoa());
        stmt.setInt(2,peslogEnt.getIdModalidade());
        stmt.setString(3,peslogEnt.getObs());
        stmt.setInt(4,peslogEnt.getId());

        // executa
        stmt.execute();
        stmt.close();
        return peslogEnt;
    }

   public List<PessoasModalidade> listar(PessoasModalidade peslogEnt) throws SQLException{
        // usus: array armazena a lista de registros

        List<PessoasModalidade> peslogs = new ArrayList<>();
        
        String sql = "select * from pessoas_modalidades where obs like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + peslogEnt.getObs()+ "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            PessoasModalidade peslog = new PessoasModalidade(
                rs.getInt(1),
                rs.getInt(2),
                rs.getInt(3),
                rs.getString(4));
            // adiciona o usu à lista de usus
            peslogs.add(peslog);
        }
        
        rs.close();
        stmt.close();
        return peslogs;
   
   }

    
}
