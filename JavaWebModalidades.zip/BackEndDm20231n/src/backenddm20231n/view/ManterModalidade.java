/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backenddm20231n.view;

import backenddm20231n.controller.ControllerModalidades;
import backenddm20231n.model.bean.Modalidade;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class ManterModalidade {
    
    public static void menu()throws SQLException, ClassNotFoundException {
        String msg = " 1 - Inserir \n 2 - Alterar \n 3 - buscar \n 4 - excluir \n 5 - Listar " ;
        int num = Integer.parseInt(JOptionPane.showInputDialog(msg));
        switch (num) {
            case 1:
                inserir();
                break;
            case 2:
                alterar();
                break;
            case 3:
                buscar();
                break;
            case 4:
                excluir();
                break;
            case 5:
                listar();
                break;
            default:
                System.out.println("Opcao inválida");
        }
    }

    private static void inserir() throws SQLException, ClassNotFoundException {
        String modalidade = JOptionPane.showInputDialog("MODALIDADE");
        String assinatura = JOptionPane.showInputDialog("ASSINATURA");
        String campo = JOptionPane.showInputDialog("CAMPO");
        Modalidade logEnt = new Modalidade(modalidade,assinatura,campo);
        ControllerModalidades contLog = new ControllerModalidades();
        Modalidade logSaida = contLog.inserir(logEnt);
        JOptionPane.showMessageDialog(null,logSaida.toString());
    }

    private static void alterar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
         String modalidade = JOptionPane.showInputDialog("MODALIDADE");
        String assinatura = JOptionPane.showInputDialog("ASSINATURA");
        String campo = JOptionPane.showInputDialog("CAMPO");
        Modalidade logEnt = new Modalidade(id,modalidade,assinatura,campo);
        ControllerModalidades contLog = new ControllerModalidades();
        Modalidade logSaida = contLog.alterar(logEnt);
        JOptionPane.showMessageDialog(null,logSaida.toString());
    }

    private static void buscar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Modalidade logEnt = new Modalidade(id);
        ControllerModalidades contLog = new ControllerModalidades();
        Modalidade logSaida = contLog.buscar(logEnt);
        JOptionPane.showMessageDialog(null,logSaida.toString());
    }

    private static void excluir() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Modalidade logEnt = new Modalidade(id);
        ControllerModalidades contLog = new ControllerModalidades();
        Modalidade logSaida = contLog.excluir(logEnt);
        JOptionPane.showMessageDialog(null,logSaida.toString());
    }

    private static void listar() throws SQLException, ClassNotFoundException {
        String cep = JOptionPane.showInputDialog("Modalidade");
        Modalidade logEnt = new Modalidade(cep);
        ControllerModalidades logUsu = new ControllerModalidades();
        List<Modalidade> listalogs = logUsu.listar(logEnt);
        for (Modalidade logSaida : listalogs) {
            JOptionPane.showMessageDialog(null,logSaida.toString());
        }
    }


}
